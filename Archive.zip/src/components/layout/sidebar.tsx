const Sidebar = () => {
  return (
    <div className="w-64 border-r p-4">
      <ul className="space-y-2">
        <li className="cursor-pointer hover:text-purple-500">Basics</li>
        <li className="cursor-pointer hover:text-purple-500">Hooks</li>
        <li className="cursor-pointer hover:text-purple-500">Forms</li>
      </ul>
    </div>
  );
};
export default Sidebar;
