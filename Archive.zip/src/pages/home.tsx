import NotesList from "../features/notes/components/notesList";

const Home = () => {
  return <NotesList />;
};
export default Home;
