import type { Note } from "../../types/note";

export const notes: Note[] = [
  {
    id: 1,
    title: "useState",
    description: "Used to manage state in React",
    category: "Hooks",
  },
  {
    id: 2,
    title: "useEffect",
    description: "Used for side effects",
    category: "Hooks",
  },
];
