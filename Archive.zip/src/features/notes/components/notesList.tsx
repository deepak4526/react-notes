import { notes } from "../../data/notesData";
import NoteCard from "./noteCard";

const NotesList = () => {
  return (
    <div className="grid gap-4">
      {notes.map((note) => (
        <NoteCard key={note.id} note={note} />
      ))}
    </div>
  );
};
export default NotesList;
